# Rotary Encoder

This is a simple library intended to be used with the Arduino framework in 
platformio. 
